import java.util.Scanner;

class Reverse {
  public static void main(String[] args) {

    Scanner myInput = new Scanner( System.in );
      int num;
      int reversed = 0;
      
      System.out.print( "Enter number: " );
      num = myInput.nextInt();
      
    System.out.println("Original Number: " + num);

    // run loop until num becomes 0
    while(num != 0) {
    
      // get last digit from num
      int digit = num % 10;
      reversed = reversed * 10 + digit;

      // remove the last digit from num
      num /= 10;
    }

    System.out.println("Reversed Number: " + reversed);
  }
}