import java.util.Arrays;
import java.util.Scanner;


public class number { 
    public static void countFreq(int array[], int n)
{
    boolean visited[] = new boolean[n];
     
    Arrays.fill(visited, false);
 
    // Traverse through array elements and
    // count frequencies
    for (int i = 0; i < n; i++) {
 
        // Skip this element if already processed
        if (visited[i] == true)
            continue;
 
        // Count frequency
        int count = 1;
        for (int j = i + 1; j < n; j++) {
            if (array[i] == array[j]) {
                visited[j] = true;
                count++;
            }
        }
        System.out.println(array[i] + " " + count);
    }
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); System.out.println("Please enter length of  array"); 
        int length = sc.nextInt();
         
    int array[] = new int[length];  
    System.out.println("Enter the elements of the array: ");  
        for(int i=0; i<length; i++)  
        {  
        //reading array elements from the user   
        array[i]=sc.nextInt();  
         }  
    System.out.println("Array elements are: ");  
    // accessing array elements using the for loop  
        for (int i=0; i<length; i++)   
        {  
        System.out.println(array[i]);  
         }
          int n = length;
         countFreq(array,n);

    }
}