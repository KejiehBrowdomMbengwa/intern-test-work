import java.util.Arrays;
import java.util.Scanner;

public class index { 
    
    static void printElements(int array[], int n)
{
    int t;
    // Traverse array from index 1 to n-2
    // and check for the given condition
    for (int i = 1; i < n - 1; i++)
    {
        if (array[i] > array[i - 1] && array[i] > array[i + 1])
        {
     
        // if array is Null
        if (array == null) {
            return -1;
        }
  
        // find length of array
        int j = 0;
  
        // traverse in the array
        while (j < n) {
  
            // if the i-th element is t
            // then return the index
            if (array[i] == t) {
                return j;
            }
            else {
                j = j + 1;
            }
        }
        return -1;
    }
        return -1;
        }
        
    
}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); System.out.println("Please enter length of  array"); 
        int length = sc.nextInt();
         
    int array[] = new int[length];  
    System.out.println("Enter the elements of the array: ");  
        for(int i=0; i<length; i++)  
        {  
        //reading array elements from the user   
        array[i]=sc.nextInt();  
         }  
    System.out.println("Array elements are: ");  
    // accessing array elements using the for loop  
        for (int i=0; i<length; i++)   
        {  
        System.out.println(array[i]);  
         }
          int n = length;
         printElements(array, n);

    }
}